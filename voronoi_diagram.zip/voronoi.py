

def midline(a,b) :
    
    # 50 100   100 50
    return (a[0]+b[0])/2, (a[1]+b[1])/2, (a[1]-b[1]), b[0]-a[0]

